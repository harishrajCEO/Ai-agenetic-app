function Dashboard() {
  try {
    const [models, setModels] = React.useState([]);
    const [alerts, setAlerts] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedIndustry, setSelectedIndustry] = React.useState(null);
    
    React.useEffect(() => {
      // Fetch initial data
      fetchDashboardData();
    }, []);
    
    React.useEffect(() => {
      // Refetch models when industry filter changes
      const filteredModels = getModels(selectedIndustry);
      setModels(filteredModels);
    }, [selectedIndustry]);
    
    const fetchDashboardData = () => {
      try {
        setLoading(true);
        // Get models based on industry filter
        const fetchedModels = getModels(selectedIndustry);
        // Get active alerts
        const fetchedAlerts = getAlerts(false);
        
        setModels(fetchedModels);
        setAlerts(fetchedAlerts);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };
    
    const handleIndustryChange = (industryId) => {
      setSelectedIndustry(industryId);
    };
    
    const handleAlertResolved = (alertId) => {
      const success = resolveAlert(alertId);
      if (success) {
        // Refresh alerts
        setAlerts(getAlerts(false));
      }
    };
    
    if (loading) {
      return (
        <div data-name="dashboard-loading" className="flex justify-center items-center h-64">
          <div data-name="loading-spinner" className="quark-spin">
            <i className="fas fa-circle-notch text-indigo-600 text-4xl"></i>
          </div>
        </div>
      );
    }
    
    return (
      <div data-name="dashboard-container">
        <h1 data-name="dashboard-title" className="text-3xl font-bold mb-6">AI Agenetic Dashboard</h1>
        
        <IndustrySelector 
          onIndustryChange={handleIndustryChange} 
          selectedIndustry={selectedIndustry} 
        />
        
        <div data-name="dashboard-metrics" className="mb-8">
          <h2 data-name="metrics-title" className="text-xl font-semibold mb-4">Performance Overview</h2>
          <PerformanceMetrics models={models} />
        </div>
        
        <div data-name="dashboard-grid" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div data-name="model-cards-section" className="lg:col-span-2">
            <div data-name="model-header" className="flex justify-between items-center mb-4">
              <h2 data-name="models-title" className="text-xl font-semibold">AI Models</h2>
              <a data-name="view-all-link" href="#" onClick={(e) => {e.preventDefault(); window.setCurrentPage('models');}} className="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                View All Models
              </a>
            </div>
            
            <div data-name="models-grid" className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {models.slice(0, 4).map(model => (
                <ModelCard key={model.id} model={model} />
              ))}
            </div>
          </div>
          
          <div data-name="alerts-section" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
            <h2 data-name="alerts-title" className="text-xl font-semibold mb-4">Active Alerts</h2>
            <AlertsPanel alerts={alerts} onResolve={handleAlertResolved} />
          </div>
        </div>
        
        <div data-name="quantum-visualizer-container" className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow p-4">
          <h2 data-name="visualizer-title" className="text-xl font-semibold mb-4">Quantum State Visualizer</h2>
          <QuantumVisualizer models={models} />
        </div>
        
        <div data-name="audit-log-container" className="mt-8">
          <h2 data-name="audit-title" className="text-xl font-semibold mb-4">Recent System Activity</h2>
          <AuditLog limit={5} />
        </div>
      </div>
    );
  } catch (error) {
    console.error('Dashboard render error:', error);
    reportError(error);
    return <div data-name="dashboard-error" className="text-red-600 p-4">Error loading dashboard. Please refresh the page.</div>;
  }
}
