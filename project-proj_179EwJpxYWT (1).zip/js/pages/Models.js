function Models() {
  try {
    const [models, setModels] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [selectedIndustry, setSelectedIndustry] = React.useState(null);
    const [selectedModel, setSelectedModel] = React.useState(null);
    const [optimizationInProgress, setOptimizationInProgress] = React.useState(false);
    
    React.useEffect(() => {
      fetchModels();
    }, [selectedIndustry]);
    
    const fetchModels = () => {
      try {
        setLoading(true);
        const fetchedModels = getModels(selectedIndustry);
        setModels(fetchedModels);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching models:', error);
        setLoading(false);
      }
    };
    
    const handleIndustryChange = (industryId) => {
      setSelectedIndustry(industryId);
      setSelectedModel(null); // Reset selected model when industry changes
    };
    
    const handleModelSelect = (model) => {
      setSelectedModel(model);
    };
    
    const handleStartOptimization = (modelId, optimizationType) => {
      setOptimizationInProgress(true);
      
      // Call the optimization service
      const success = startModelOptimization(modelId, optimizationType);
      
      if (success) {
        // Refresh the models list after a brief delay to simulate processing
        setTimeout(() => {
          fetchModels();
          setOptimizationInProgress(false);
          
          // If the currently selected model was optimized, refresh its data
          if (selectedModel && selectedModel.id === modelId) {
            const updatedModel = getModelById(modelId);
            setSelectedModel(updatedModel);
          }
        }, 1500);
      } else {
        setOptimizationInProgress(false);
      }
    };
    
    const renderModelDetails = () => {
      if (!selectedModel) {
        return (
          <div data-name="no-model-selected" className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 h-full flex flex-col items-center justify-center text-center">
            <i className="fas fa-robot text-4xl text-indigo-500 mb-4"></i>
            <h3 data-name="select-model-prompt" className="text-lg font-medium mb-2">Select a Model</h3>
            <p data-name="select-model-desc" className="text-slate-500 dark:text-slate-400">
              Select an AI model from the registry to view its details and performance metrics
            </p>
          </div>
        );
      }
      
      const performanceHistory = getPerformanceHistory(selectedModel.id);
      const optimizations = getOptimizations(selectedModel.id);
      
      return (
        <div data-name="model-details" className="bg-white dark:bg-slate-800 rounded-lg shadow">
          <div data-name="model-header" className="p-6 border-b border-slate-200 dark:border-slate-700">
            <div data-name="model-title-row" className="flex justify-between items-center">
              <h2 data-name="model-name" className="text-2xl font-bold">{selectedModel.name}</h2>
              <div data-name="model-status" className={`status-badge status-${selectedModel.status.toLowerCase()}`}>
                <span data-name="status-icon" className="mr-1">
                  {selectedModel.status === 'healthy' && <i className="fas fa-check-circle"></i>}
                  {selectedModel.status === 'warning' && <i className="fas fa-exclamation-triangle"></i>}
                  {selectedModel.status === 'critical' && <i className="fas fa-times-circle"></i>}
                  {selectedModel.status === 'optimizing' && <i className="fas fa-cog fa-spin"></i>}
                </span>
                <span data-name="status-text">{selectedModel.status.charAt(0).toUpperCase() + selectedModel.status.slice(1)}</span>
              </div>
            </div>
            <p data-name="model-desc" className="mt-2 text-slate-600 dark:text-slate-300">{selectedModel.description}</p>
          </div>
          
          <div data-name="model-metrics" className="p-6 border-b border-slate-200 dark:border-slate-700">
            <h3 data-name="metrics-title" className="text-lg font-semibold mb-4">Performance Metrics</h3>
            <div data-name="metrics-grid" className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div data-name="metric-card" className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg">
                <div data-name="metric-label" className="text-sm text-slate-500 dark:text-slate-400 mb-1">Accuracy</div>
                <div data-name="metric-value" className="text-2xl font-bold">{selectedModel.accuracy}%</div>
              </div>
              <div data-name="metric-card" className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg">
                <div data-name="metric-label" className="text-sm text-slate-500 dark:text-slate-400 mb-1">Latency</div>
                <div data-name="metric-value" className="text-2xl font-bold">{selectedModel.latency} ms</div>
              </div>
              <div data-name="metric-card" className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg">
                <div data-name="metric-label" className="text-sm text-slate-500 dark:text-slate-400 mb-1">Precision</div>
                <div data-name="metric-value" className="text-2xl font-bold">{selectedModel.metrics.precision.toFixed(2)}</div>
              </div>
              <div data-name="metric-card" className="bg-slate-50 dark:bg-slate-700 p-4 rounded-lg">
                <div data-name="metric-label" className="text-sm text-slate-500 dark:text-slate-400 mb-1">Recall</div>
                <div data-name="metric-value" className="text-2xl font-bold">{selectedModel.metrics.recall.toFixed(2)}</div>
              </div>
            </div>
          </div>
          
          <div data-name="optimization-section" className="p-6">
            <h3 data-name="optimization-title" className="text-lg font-semibold mb-4">Model Optimization</h3>
            <OptimizationPanel 
              modelId={selectedModel.id}
              onStartOptimization={handleStartOptimization}
              optimizations={optimizations}
              inProgress={optimizationInProgress || selectedModel.status === 'optimizing'}
            />
          </div>
        </div>
      );
    };
    
    return (
      <div data-name="models-page-container">
        <h1 data-name="models-page-title" className="text-3xl font-bold mb-6">AI Model Registry</h1>
        
        <IndustrySelector 
          onIndustryChange={handleIndustryChange} 
          selectedIndustry={selectedIndustry} 
        />
        
        {loading ? (
          <div data-name="models-loading" className="flex justify-center items-center h-64">
            <div data-name="loading-spinner" className="quark-spin">
              <i className="fas fa-circle-notch text-indigo-600 text-4xl"></i>
            </div>
          </div>
        ) : (
          <div data-name="models-content" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div data-name="model-registry-container" className="lg:col-span-1">
              <ModelRegistry 
                models={models} 
                selectedModelId={selectedModel?.id} 
                onModelSelect={handleModelSelect} 
              />
            </div>
            <div data-name="model-details-container" className="lg:col-span-2">
              {renderModelDetails()}
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('Models page render error:', error);
    reportError(error);
    return <div data-name="models-error" className="text-red-600 p-4">Error loading models. Please refresh the page.</div>;
  }
}
