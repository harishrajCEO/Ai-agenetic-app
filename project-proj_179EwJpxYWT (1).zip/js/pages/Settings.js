function Settings({ darkMode, toggleDarkMode }) {
  try {
    const [settings, setSettings] = React.useState({
      autoOptimize: true,
      notificationsEnabled: true,
      dataRetentionDays: 30,
      securityLevel: 'high',
      modelUpdateFrequency: 'weekly',
      quantumSimulationDepth: 'medium'
    });
    
    const [saved, setSaved] = React.useState(false);
    
    const handleToggle = (setting) => {
      setSettings(prev => ({
        ...prev,
        [setting]: !prev[setting]
      }));
      setSaved(false);
    };
    
    const handleChange = (setting, value) => {
      setSettings(prev => ({
        ...prev,
        [setting]: value
      }));
      setSaved(false);
    };
    
    const handleSave = () => {
      // Simulate saving settings
      setTimeout(() => {
        setSaved(true);
        
        // Add to audit logs
        const auditLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'settings_changed',
          description: 'System settings were updated',
          user: 'user'
        };
        
        // In a real app, we would save this to the backend
        console.log('Settings saved:', settings);
        console.log('Audit log created:', auditLog);
        
        // Hide the saved message after 3 seconds
        setTimeout(() => setSaved(false), 3000);
      }, 500);
    };
    
    return (
      <div data-name="settings-container">
        <h1 data-name="settings-title" className="text-3xl font-bold mb-6">System Settings</h1>
        
        {saved && (
          <div data-name="saved-message" className="mb-6 p-4 bg-green-100 text-green-800 rounded-lg flex items-center">
            <i className="fas fa-check-circle mr-2"></i>
            <span>Settings saved successfully</span>
          </div>
        )}
        
        <div data-name="settings-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div data-name="appearance-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="appearance-title" className="text-xl font-semibold mb-4">Appearance</h2>
            
            <div data-name="theme-toggle" className="flex items-center justify-between mb-4">
              <div>
                <h3 data-name="theme-label" className="font-medium">Dark Mode</h3>
                <p data-name="theme-desc" className="text-sm text-slate-500 dark:text-slate-400">
                  Toggle between light and dark theme
                </p>
              </div>
              <label data-name="theme-switch" className="toggle-switch">
                <input 
                  type="checkbox" 
                  checked={darkMode}
                  onChange={toggleDarkMode}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
          </div>
          
          <div data-name="notifications-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="notifications-title" className="text-xl font-semibold mb-4">Notifications</h2>
            
            <div data-name="notifications-toggle" className="flex items-center justify-between mb-4">
              <div>
                <h3 data-name="notifications-label" className="font-medium">Enable Notifications</h3>
                <p data-name="notifications-desc" className="text-sm text-slate-500 dark:text-slate-400">
                  Receive alerts about model performance and system events
                </p>
              </div>
              <label data-name="notifications-switch" className="toggle-switch">
                <input 
                  type="checkbox" 
                  checked={settings.notificationsEnabled}
                  onChange={() => handleToggle('notificationsEnabled')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
          </div>
          
          <div data-name="optimization-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="optimization-title" className="text-xl font-semibold mb-4">Model Optimization</h2>
            
            <div data-name="auto-optimize-toggle" className="flex items-center justify-between mb-4">
              <div>
                <h3 data-name="auto-optimize-label" className="font-medium">Auto-Optimization</h3>
                <p data-name="auto-optimize-desc" className="text-sm text-slate-500 dark:text-slate-400">
                  Automatically optimize models when performance degrades
                </p>
              </div>
              <label data-name="auto-optimize-switch" className="toggle-switch">
                <input 
                  type="checkbox" 
                  checked={settings.autoOptimize}
                  onChange={() => handleToggle('autoOptimize')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            
            <div data-name="update-frequency" className="mb-4">
              <h3 data-name="update-frequency-label" className="font-medium mb-2">Model Update Frequency</h3>
              <select
                data-name="update-frequency-select"
                className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                value={settings.modelUpdateFrequency}
                onChange={(e) => handleChange('modelUpdateFrequency', e.target.value)}
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
              </select>
            </div>
          </div>
          
          <div data-name="quantum-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="quantum-title" className="text-xl font-semibold mb-4">Quantum Simulation</h2>
            
            <div data-name="simulation-depth" className="mb-4">
              <h3 data-name="simulation-depth-label" className="font-medium mb-2">Simulation Depth</h3>
              <p data-name="simulation-depth-desc" className="text-sm text-slate-500 dark:text-slate-400 mb-2">
                Controls the complexity of quantum-inspired algorithms
              </p>
              <select
                data-name="simulation-depth-select"
                className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                value={settings.quantumSimulationDepth}
                onChange={(e) => handleChange('quantumSimulationDepth', e.target.value)}
              >
                <option value="low">Low (Faster, Less Accurate)</option>
                <option value="medium">Medium (Balanced)</option>
                <option value="high">High (Slower, More Accurate)</option>
                <option value="extreme">Extreme (Resource Intensive)</option>
              </select>
            </div>
          </div>
          
          <div data-name="data-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="data-title" className="text-xl font-semibold mb-4">Data Management</h2>
            
            <div data-name="data-retention" className="mb-4">
              <h3 data-name="data-retention-label" className="font-medium mb-2">Data Retention Period (days)</h3>
              <input
                data-name="data-retention-input"
                type="number"
                min="1"
                max="365"
                className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                value={settings.dataRetentionDays}
                onChange={(e) => handleChange('dataRetentionDays', parseInt(e.target.value))}
              />
            </div>
          </div>
          
          <div data-name="security-section" className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow">
            <h2 data-name="security-title" className="text-xl font-semibold mb-4">Security</h2>
            
            <div data-name="security-level" className="mb-4">
              <h3 data-name="security-level-label" className="font-medium mb-2">Security Level</h3>
              <select
                data-name="security-level-select"
                className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                value={settings.securityLevel}
                onChange={(e) => handleChange('securityLevel', e.target.value)}
              >
                <option value="standard">Standard</option>
                <option value="high">High</option>
                <option value="enterprise">Enterprise</option>
              </select>
            </div>
          </div>
        </div>
        
        <div data-name="actions" className="mt-6 flex justify-end">
          <button
            data-name="save-button"
            className="px-6 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            onClick={handleSave}
          >
            Save Settings
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Settings render error:', error);
    reportError(error);
    return <div data-name="settings-error" className="text-red-600 p-4">Error loading settings. Please refresh the page.</div>;
  }
}
