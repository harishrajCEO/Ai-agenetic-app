function Analytics() {
  try {
    const [models, setModels] = React.useState([]);
    const [selectedModel, setSelectedModel] = React.useState(null);
    const [performanceData, setPerformanceData] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    
    React.useEffect(() => {
      fetchModels();
    }, []);
    
    React.useEffect(() => {
      if (selectedModel) {
        fetchPerformanceData(selectedModel.id);
      }
    }, [selectedModel]);
    
    const fetchModels = () => {
      try {
        const fetchedModels = getModels();
        setModels(fetchedModels);
        
        // Select the first model by default
        if (fetchedModels.length > 0 && !selectedModel) {
          setSelectedModel(fetchedModels[0]);
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error('Error fetching models for analytics:', error);
        setLoading(false);
      }
    };
    
    const fetchPerformanceData = (modelId) => {
      try {
        setLoading(true);
        const data = getPerformanceHistory(modelId);
        setPerformanceData(data);
        setLoading(false);
      } catch (error) {
        console.error(`Error fetching performance data for model ${modelId}:`, error);
        setLoading(false);
      }
    };
    
    const handleModelChange = (e) => {
      const modelId = e.target.value;
      const model = models.find(m => m.id === modelId);
      setSelectedModel(model);
    };
    
    // Function to render a simple chart with performance data
    const renderPerformanceChart = () => {
      if (!performanceData || performanceData.length === 0) {
        return (
          <div data-name="no-data" className="text-center p-10 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <p data-name="no-data-message">No performance data available for this model.</p>
          </div>
        );
      }
      
      const chartHeight = 200;
      const chartWidth = '100%';
      const padding = 40;
      
      // Get min and max values for scaling
      const maxAccuracy = Math.max(...performanceData.map(d => d.accuracy));
      const minAccuracy = Math.min(...performanceData.map(d => d.accuracy));
      const accuracyRange = maxAccuracy - minAccuracy || 1;
      
      const maxLatency = Math.max(...performanceData.map(d => d.latency));
      const minLatency = Math.min(...performanceData.map(d => d.latency));
      const latencyRange = maxLatency - minLatency || 1;
      
      // Scale points to fit chart
      const scaleAccuracy = (value) => {
        return chartHeight - ((value - minAccuracy) / accuracyRange * (chartHeight - padding * 2) + padding);
      };
      
      const scaleLatency = (value) => {
        return chartHeight - ((value - minLatency) / latencyRange * (chartHeight - padding * 2) + padding);
      };
      
      // Generate points for paths
      const accuracyPoints = performanceData.map((d, i) => {
        const x = i * (100 / (performanceData.length - 1)) + '%';
        const y = scaleAccuracy(d.accuracy);
        return `${x},${y}`;
      }).join(' ');
      
      const latencyPoints = performanceData.map((d, i) => {
        const x = i * (100 / (performanceData.length - 1)) + '%';
        const y = scaleLatency(d.latency);
        return `${x},${y}`;
      }).join(' ');
      
      return (
        <div data-name="chart-container" className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow">
          <h3 data-name="chart-title" className="text-lg font-semibold mb-4">Performance Trends</h3>
          
          <div data-name="chart-legend" className="flex gap-4 mb-4">
            <div data-name="accuracy-legend" className="flex items-center">
              <div data-name="legend-color" className="w-3 h-3 bg-indigo-500 rounded-full mr-2"></div>
              <span data-name="legend-label">Accuracy</span>
            </div>
            <div data-name="latency-legend" className="flex items-center">
              <div data-name="legend-color" className="w-3 h-3 bg-rose-500 rounded-full mr-2"></div>
              <span data-name="legend-label">Latency</span>
            </div>
          </div>
          
          <div data-name="chart-wrapper" style={{ height: `${chartHeight}px`, position: 'relative' }}>
            <svg width={chartWidth} height={chartHeight} viewBox={`0 0 100 ${chartHeight}`} preserveAspectRatio="none">
              {/* Grid lines */}
              <line x1="0" y1={padding} x2="100%" y2={padding} stroke="#e2e8f0" strokeDasharray="2" />
              <line x1="0" y1={chartHeight - padding} x2="100%" y2={chartHeight - padding} stroke="#e2e8f0" strokeDasharray="2" />
              <line x1="0" y1={chartHeight/2} x2="100%" y2={chartHeight/2} stroke="#e2e8f0" strokeDasharray="2" />
              
              {/* Accuracy line */}
              <polyline
                fill="none"
                stroke="#6366f1"
                strokeWidth="2"
                points={accuracyPoints}
              />
              
              {/* Latency line */}
              <polyline
                fill="none"
                stroke="#f43f5e"
                strokeWidth="2"
                points={latencyPoints}
              />
              
              {/* Data points for accuracy */}
              {performanceData.map((d, i) => (
                <circle
                  key={`accuracy-${i}`}
                  cx={`${i * (100 / (performanceData.length - 1))}%`}
                  cy={scaleAccuracy(d.accuracy)}
                  r="3"
                  fill="#6366f1"
                />
              ))}
              
              {/* Data points for latency */}
              {performanceData.map((d, i) => (
                <circle
                  key={`latency-${i}`}
                  cx={`${i * (100 / (performanceData.length - 1))}%`}
                  cy={scaleLatency(d.latency)}
                  r="3"
                  fill="#f43f5e"
                />
              ))}
            </svg>
            
            {/* X-axis labels */}
            <div data-name="x-axis-labels" className="flex justify-between mt-2 px-2">
              {performanceData.map((d, i) => (
                <div key={`label-${i}`} className="text-xs text-slate-500">
                  {d.date.split('-')[2]}
                </div>
              ))}
            </div>
          </div>
          
          <div data-name="axis-labels" className="flex justify-between mt-4">
            <div data-name="y-axis-label-accuracy" className="text-xs text-slate-500">
              Accuracy: {minAccuracy.toFixed(1)}% - {maxAccuracy.toFixed(1)}%
            </div>
            <div data-name="y-axis-label-latency" className="text-xs text-slate-500">
              Latency: {minLatency}ms - {maxLatency}ms
            </div>
          </div>
        </div>
      );
    };
    
    // Function to render the optimization history
    const renderOptimizationHistory = () => {
      if (!selectedModel) return null;
      
      const optimizations = getOptimizations(selectedModel.id);
      
      if (optimizations.length === 0) {
        return (
          <div data-name="no-optimizations" className="text-center p-10 bg-slate-50 dark:bg-slate-800 rounded-lg">
            <p data-name="no-optimizations-message">No optimization history available for this model.</p>
          </div>
        );
      }
      
      return (
        <div data-name="optimization-history" className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow">
          <h3 data-name="optimization-title" className="text-lg font-semibold mb-4">Optimization History</h3>
          
          <div data-name="optimization-timeline" className="optimization-timeline">
            {optimizations.map(opt => (
              <div data-name="timeline-item" key={opt.id} className="timeline-item">
                <div data-name="timeline-content" className="ml-2">
                  <div data-name="timeline-header" className="flex justify-between">
                    <h4 data-name="optimization-type" className="font-medium">{opt.type.charAt(0).toUpperCase() + opt.type.slice(1)} Optimization</h4>
                    <span data-name="optimization-date" className="text-sm text-slate-500">{formatDate(opt.startTime)}</span>
                  </div>
                  <p data-name="optimization-desc" className="text-sm mt-1">{opt.description}</p>
                  
                  <div data-name="optimization-status" className="mt-2 flex items-center">
                    <span data-name="status-label" className="text-sm mr-2">Status:</span>
                    <span data-name="status-value" className={`text-sm font-medium ${
                      opt.status === 'completed' ? 'text-green-600' : 
                      opt.status === 'failed' ? 'text-red-600' : 'text-indigo-600'
                    }`}>
                      {opt.status.charAt(0).toUpperCase() + opt.status.slice(1)}
                    </span>
                  </div>
                  
                  {opt.status === 'completed' && (
                    <div data-name="improvements" className="mt-2 grid grid-cols-2 gap-2">
                      <div data-name="accuracy-change" className="bg-slate-50 dark:bg-slate-700 p-2 rounded">
                        <span data-name="accuracy-label" className="text-xs text-slate-500">Accuracy Change</span>
                        <div data-name="accuracy-value" className={`text-sm font-medium ${
                          opt.improvements.accuracyChange.startsWith('+') ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {opt.improvements.accuracyChange}
                        </div>
                      </div>
                      <div data-name="latency-change" className="bg-slate-50 dark:bg-slate-700 p-2 rounded">
                        <span data-name="latency-label" className="text-xs text-slate-500">Latency Change</span>
                        <div data-name="latency-value" className={`text-sm font-medium ${
                          opt.improvements.latencyChange.startsWith('-') ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {opt.improvements.latencyChange}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    };
    
    // Function to render the model statistics section
    const renderModelStatistics = () => {
      if (!selectedModel) return null;
      
      return (
        <div data-name="model-statistics" className="bg-white dark:bg-slate-800 rounded-lg p-4 shadow">
          <h3 data-name="statistics-title" className="text-lg font-semibold mb-4">Model Statistics</h3>
          
          <div data-name="statistics-grid" className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div data-name="stat-card" className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div data-name="stat-label" className="text-xs text-slate-500 mb-1">Current Accuracy</div>
              <div data-name="stat-value" className="text-xl font-bold">{selectedModel.accuracy}%</div>
            </div>
            
            <div data-name="stat-card" className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div data-name="stat-label" className="text-xs text-slate-500 mb-1">Current Latency</div>
              <div data-name="stat-value" className="text-xl font-bold">{selectedModel.latency} ms</div>
            </div>
            
            <div data-name="stat-card" className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div data-name="stat-label" className="text-xs text-slate-500 mb-1">F1 Score</div>
              <div data-name="stat-value" className="text-xl font-bold">{selectedModel.metrics.f1Score.toFixed(2)}</div>
            </div>
            
            <div data-name="stat-card" className="p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div data-name="stat-label" className="text-xs text-slate-500 mb-1">Resource Usage</div>
              <div data-name="stat-value" className="text-xl font-bold">{selectedModel.metrics.resourceUsage}%</div>
            </div>
          </div>
          
          <div data-name="advanced-metrics" className="mt-4">
            <h4 data-name="advanced-title" className="text-md font-medium mb-3">Advanced Metrics</h4>
            
            <div data-name="metrics-table" className="w-full">
              <div data-name="table-row" className="grid grid-cols-2 gap-2 mb-2">
                <div data-name="metric-name" className="text-sm font-medium">Precision</div>
                <div data-name="metric-value" className="text-sm">{selectedModel.metrics.precision.toFixed(3)}</div>
              </div>
              <div data-name="table-row" className="grid grid-cols-2 gap-2 mb-2">
                <div data-name="metric-name" className="text-sm font-medium">Recall</div>
                <div data-name="metric-value" className="text-sm">{selectedModel.metrics.recall.toFixed(3)}</div>
              </div>
              <div data-name="table-row" className="grid grid-cols-2 gap-2 mb-2">
                <div data-name="metric-name" className="text-sm font-medium">Last Optimized</div>
                <div data-name="metric-value" className="text-sm">{formatDate(selectedModel.lastOptimized)}</div>
              </div>
              <div data-name="table-row" className="grid grid-cols-2 gap-2">
                <div data-name="metric-name" className="text-sm font-medium">Status</div>
                <div data-name="metric-value" className="text-sm">
                  <span className={`status-badge status-${selectedModel.status.toLowerCase()}`}>
                    {selectedModel.status.charAt(0).toUpperCase() + selectedModel.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    };
    
    return (
      <div data-name="analytics-container">
        <h1 data-name="analytics-title" className="text-3xl font-bold mb-6">Analytics & Insights</h1>
        
        <div data-name="model-selector" className="mb-6">
          <label data-name="selector-label" htmlFor="model-select" className="block text-sm font-medium mb-2">
            Select Model to Analyze
          </label>
          <select
            id="model-select"
            data-name="model-dropdown"
            className="block w-full md:w-1/2 lg:w-1/3 px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-800"
            value={selectedModel?.id || ''}
            onChange={handleModelChange}
          >
            {models.map(model => (
              <option key={model.id} value={model.id}>
                {model.name} ({model.industry.charAt(0).toUpperCase() + model.industry.slice(1)})
              </option>
            ))}
          </select>
        </div>
        
        {loading ? (
          <div data-name="analytics-loading" className="flex justify-center items-center h-64">
            <div data-name="loading-spinner" className="quark-spin">
              <i className="fas fa-circle-notch text-indigo-600 text-4xl"></i>
            </div>
          </div>
        ) : (
          <div data-name="analytics-content">
            {selectedModel && (
              <div data-name="model-overview" className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow mb-6">
                <h2 data-name="model-name" className="text-xl font-semibold">{selectedModel.name}</h2>
                <p data-name="model-desc" className="text-slate-600 dark:text-slate-300 mt-1">{selectedModel.description}</p>
                <div data-name="model-meta" className="mt-2 flex flex-wrap gap-4">
                  <div data-name="industry" className="flex items-center">
                    <i className="fas fa-building text-slate-400 mr-2"></i>
                    <span data-name="industry-name">{selectedModel.industry.charAt(0).toUpperCase() + selectedModel.industry.slice(1)}</span>
                  </div>
                  <div data-name="last-optimized" className="flex items-center">
                    <i className="fas fa-calendar text-slate-400 mr-2"></i>
                    <span data-name="optimization-date">Last optimized: {formatDate(selectedModel.lastOptimized)}</span>
                  </div>
                </div>
              </div>
            )}
            
            <div data-name="analytics-grid" className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div data-name="chart-container">
                {renderPerformanceChart()}
              </div>
              <div data-name="statistics-container">
                {renderModelStatistics()}
              </div>
            </div>
            
            <div data-name="optimization-history-container">
              {renderOptimizationHistory()}
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('Analytics render error:', error);
    reportError(error);
    return <div data-name="analytics-error" className="text-red-600 p-4">Error loading analytics. Please refresh the page.</div>;
  }
}
