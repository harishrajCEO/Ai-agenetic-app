function formatNumber(number) {
  try {
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1) + 'M';
    } else if (number >= 1000) {
      return (number / 1000).toFixed(1) + 'K';
    } else {
      return number.toString();
    }
  } catch (error) {
    console.error('Format number error:', error);
    reportError(error);
    return '0';
  }
}

function formatDate(dateString) {
  try {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  } catch (error) {
    console.error('Format date error:', error);
    reportError(error);
    return 'Invalid date';
  }
}

function generateId() {
  try {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  } catch (error) {
    console.error('Generate ID error:', error);
    reportError(error);
    return 'id-' + Date.now();
  }
}

function getStatusColor(status) {
  try {
    const colors = {
      healthy: 'green',
      warning: 'yellow',
      critical: 'red',
      optimizing: 'indigo'
    };
    return colors[status.toLowerCase()] || 'gray';
  } catch (error) {
    console.error('Get status color error:', error);
    reportError(error);
    return 'gray';
  }
}

function debounce(func, wait) {
  try {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  } catch (error) {
    console.error('Debounce error:', error);
    reportError(error);
    return func;
  }
}

function throttle(func, limit) {
  try {
    let inThrottle;
    return function(...args) {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  } catch (error) {
    console.error('Throttle error:', error);
    reportError(error);
    return func;
  }
}
