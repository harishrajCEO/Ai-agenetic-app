// Theme management utilities

// Get the current theme preference from local storage
function getThemePreference() {
  try {
    // Check if there's a saved preference in local storage
    const savedTheme = localStorage.getItem('ai-agenetic-theme');
    
    // If there's a saved preference, return it
    if (savedTheme) {
      return savedTheme;
    }
    
    // Otherwise, check if the user's system prefers dark mode
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    
    // Default to light mode
    return 'light';
  } catch (error) {
    console.error('Error getting theme preference:', error);
    reportError(error);
    return 'light'; // Default to light mode if there's an error
  }
}

// Save theme preference to local storage
function saveThemePreference(theme) {
  try {
    localStorage.setItem('ai-agenetic-theme', theme);
  } catch (error) {
    console.error('Error saving theme preference:', error);
    reportError(error);
  }
}

// Apply theme to the document
function applyTheme(theme) {
  try {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // You could also update meta theme-color for mobile browsers
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', theme === 'dark' ? '#0f172a' : '#ffffff');
    }
  } catch (error) {
    console.error('Error applying theme:', error);
    reportError(error);
  }
}
