// Mock data for the application
const mockData = {
  models: [
    {
      id: 'model-1',
      name: 'Healthcare Diagnosis Predictor',
      industry: 'healthcare',
      status: 'healthy',
      accuracy: 96.7,
      latency: 120,
      lastOptimized: '2023-11-15T14:30:00Z',
      description: 'Predicts patient diagnoses based on symptoms, medical history, and test results',
      metrics: {
        precision: 0.94,
        recall: 0.91,
        f1Score: 0.92,
        resourceUsage: 65
      }
    },
    {
      id: 'model-2',
      name: 'Financial Fraud Detection',
      industry: 'finance',
      status: 'warning',
      accuracy: 92.3,
      latency: 85,
      lastOptimized: '2023-11-10T09:15:00Z',
      description: 'Detects fraudulent transactions in real-time payment processing',
      metrics: {
        precision: 0.89,
        recall: 0.85,
        f1Score: 0.87,
        resourceUsage: 78
      }
    },
    {
      id: 'model-3',
      name: 'Manufacturing Defect Detection',
      industry: 'manufacturing',
      status: 'optimizing',
      accuracy: 88.5,
      latency: 210,
      lastOptimized: '2023-11-18T11:45:00Z',
      description: 'Identifies product defects from visual inspection data',
      metrics: {
        precision: 0.86,
        recall: 0.82,
        f1Score: 0.84,
        resourceUsage: 92
      }
    },
    {
      id: 'model-4',
      name: 'Customer Churn Predictor',
      industry: 'telecom',
      status: 'critical',
      accuracy: 78.9,
      latency: 95,
      lastOptimized: '2023-10-25T16:20:00Z',
      description: 'Predicts customer churn likelihood based on usage patterns',
      metrics: {
        precision: 0.76,
        recall: 0.72,
        f1Score: 0.74,
        resourceUsage: 45
      }
    },
    {
      id: 'model-5',
      name: 'Energy Consumption Forecaster',
      industry: 'energy',
      status: 'healthy',
      accuracy: 94.1,
      latency: 150,
      lastOptimized: '2023-11-12T08:30:00Z',
      description: 'Forecasts energy consumption for grid optimization',
      metrics: {
        precision: 0.93,
        recall: 0.92,
        f1Score: 0.92,
        resourceUsage: 70
      }
    }
  ],
  
  alerts: [
    {
      id: 'alert-1',
      modelId: 'model-2',
      type: 'warning',
      message: 'Accuracy drop detected in Financial Fraud Detection model',
      timestamp: '2023-11-18T14:22:00Z',
      resolved: false
    },
    {
      id: 'alert-2',
      modelId: 'model-4',
      type: 'critical',
      message: 'Customer Churn Predictor showing significant performance degradation',
      timestamp: '2023-11-18T10:15:00Z',
      resolved: false
    },
    {
      id: 'alert-3',
      modelId: 'model-3',
      type: 'info',
      message: 'Optimization in progress for Manufacturing Defect Detection model',
      timestamp: '2023-11-18T11:45:00Z',
      resolved: false
    },
    {
      id: 'alert-4',
      modelId: 'model-1',
      type: 'success',
      message: 'Healthcare Diagnosis Predictor successfully optimized',
      timestamp: '2023-11-15T14:35:00Z',
      resolved: true
    }
  ],
  
  industries: [
    { id: 'healthcare', name: 'Healthcare', icon: 'fa-solid fa-stethoscope', color: 'bg-blue-100 text-blue-600' },
    { id: 'finance', name: 'Finance', icon: 'fa-solid fa-landmark', color: 'bg-green-100 text-green-600' },
    { id: 'manufacturing', name: 'Manufacturing', icon: 'fa-solid fa-industry', color: 'bg-yellow-100 text-yellow-600' },
    { id: 'telecom', name: 'Telecom', icon: 'fa-solid fa-tower-cell', color: 'bg-purple-100 text-purple-600' },
    { id: 'energy', name: 'Energy', icon: 'fa-solid fa-bolt', color: 'bg-red-100 text-red-600' },
    { id: 'retail', name: 'Retail', icon: 'fa-solid fa-shopping-cart', color: 'bg-pink-100 text-pink-600' },
    { id: 'logistics', name: 'Logistics', icon: 'fa-solid fa-truck', color: 'bg-indigo-100 text-indigo-600' }
  ],
  
  optimizations: [
    {
      id: 'opt-1',
      modelId: 'model-3',
      type: 'hyperparameter',
      description: 'Adjusting learning rate and batch size',
      startTime: '2023-11-18T11:45:00Z',
      endTime: '2023-11-18T12:30:00Z',
      status: 'in-progress',
      improvements: {
        accuracyChange: '+2.4%',
        latencyChange: '-15ms'
      }
    },
    {
      id: 'opt-2',
      modelId: 'model-1',
      type: 'retraining',
      description: 'Full model retraining with expanded dataset',
      startTime: '2023-11-15T13:20:00Z',
      endTime: '2023-11-15T14:30:00Z',
      status: 'completed',
      improvements: {
        accuracyChange: '+1.8%',
        latencyChange: '-8ms'
      }
    },
    {
      id: 'opt-3',
      modelId: 'model-2',
      type: 'ensemble',
      description: 'Creating ensemble with gradient boosting model',
      startTime: '2023-11-17T09:10:00Z',
      endTime: '2023-11-17T10:45:00Z',
      status: 'failed',
      improvements: {
        accuracyChange: '0%',
        latencyChange: '+25ms'
      }
    }
  ],
  
  auditLogs: [
    {
      id: 'log-1',
      timestamp: '2023-11-18T14:22:00Z',
      action: 'alert_generated',
      description: 'Alert generated for Financial Fraud Detection model',
      user: 'system'
    },
    {
      id: 'log-2',
      timestamp: '2023-11-18T11:45:00Z',
      action: 'optimization_started',
      description: 'Optimization started for Manufacturing Defect Detection model',
      user: 'system'
    },
    {
      id: 'log-3',
      timestamp: '2023-11-17T10:45:00Z',
      action: 'optimization_failed',
      description: 'Ensemble optimization failed for Financial Fraud Detection model',
      user: 'system'
    },
    {
      id: 'log-4',
      timestamp: '2023-11-15T14:30:00Z',
      action: 'model_updated',
      description: 'Healthcare Diagnosis Predictor model updated after retraining',
      user: 'system'
    },
    {
      id: 'log-5',
      timestamp: '2023-11-15T10:15:00Z',
      action: 'settings_changed',
      description: 'Auto-optimization threshold changed for Healthcare industry',
      user: 'admin'
    }
  ],
  
  performanceHistory: {
    'model-1': [
      { date: '2023-11-10', accuracy: 94.2, latency: 135 },
      { date: '2023-11-11', accuracy: 94.5, latency: 132 },
      { date: '2023-11-12', accuracy: 94.3, latency: 133 },
      { date: '2023-11-13', accuracy: 94.8, latency: 130 },
      { date: '2023-11-14', accuracy: 95.1, latency: 128 },
      { date: '2023-11-15', accuracy: 96.7, latency: 120 },
      { date: '2023-11-16', accuracy: 96.5, latency: 122 },
      { date: '2023-11-17', accuracy: 96.6, latency: 121 },
      { date: '2023-11-18', accuracy: 96.7, latency: 120 }
    ],
    'model-2': [
      { date: '2023-11-10', accuracy: 93.5, latency: 82 },
      { date: '2023-11-11', accuracy: 93.2, latency: 83 },
      { date: '2023-11-12', accuracy: 93.0, latency: 84 },
      { date: '2023-11-13', accuracy: 92.8, latency: 84 },
      { date: '2023-11-14', accuracy: 92.5, latency: 85 },
      { date: '2023-11-15', accuracy: 92.3, latency: 85 },
      { date: '2023-11-16', accuracy: 92.4, latency: 85 },
      { date: '2023-11-17', accuracy: 92.2, latency: 86 },
      { date: '2023-11-18', accuracy: 92.3, latency: 85 }
    ]
  }
};

// Data service functions
function getModels(industryFilter = null) {
  try {
    if (industryFilter) {
      return mockData.models.filter(model => model.industry === industryFilter);
    }
    return mockData.models;
  } catch (error) {
    console.error('Error fetching models:', error);
    return [];
  }
}

function getModelById(id) {
  try {
    return mockData.models.find(model => model.id === id);
  } catch (error) {
    console.error(`Error fetching model with ID ${id}:`, error);
    return null;
  }
}

function getAlerts(resolved = false) {
  try {
    return mockData.alerts.filter(alert => alert.resolved === resolved);
  } catch (error) {
    console.error('Error fetching alerts:', error);
    return [];
  }
}

function getIndustries() {
  try {
    return mockData.industries;
  } catch (error) {
    console.error('Error fetching industries:', error);
    return [];
  }
}

function getOptimizations(modelId = null) {
  try {
    if (modelId) {
      return mockData.optimizations.filter(opt => opt.modelId === modelId);
    }
    return mockData.optimizations;
  } catch (error) {
    console.error('Error fetching optimizations:', error);
    return [];
  }
}

function getAuditLogs(limit = 10) {
  try {
    return mockData.auditLogs.slice(0, limit);
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    return [];
  }
}

function getPerformanceHistory(modelId) {
  try {
    return mockData.performanceHistory[modelId] || [];
  } catch (error) {
    console.error(`Error fetching performance history for model ${modelId}:`, error);
    return [];
  }
}

function resolveAlert(alertId) {
  try {
    const alertIndex = mockData.alerts.findIndex(alert => alert.id === alertId);
    if (alertIndex !== -1) {
      mockData.alerts[alertIndex].resolved = true;
      
      // Add to audit logs
      mockData.auditLogs.unshift({
        id: `log-${mockData.auditLogs.length + 1}`,
        timestamp: new Date().toISOString(),
        action: 'alert_resolved',
        description: `Alert resolved: ${mockData.alerts[alertIndex].message}`,
        user: 'user'
      });
      
      return true;
    }
    return false;
  } catch (error) {
    console.error(`Error resolving alert ${alertId}:`, error);
    return false;
  }
}

function startModelOptimization(modelId, type) {
  try {
    const model = getModelById(modelId);
    if (!model) return false;
    
    // Update model status
    const modelIndex = mockData.models.findIndex(m => m.id === modelId);
    if (modelIndex !== -1) {
      mockData.models[modelIndex].status = 'optimizing';
    }
    
    // Create optimization record
    const newOptimization = {
      id: `opt-${mockData.optimizations.length + 1}`,
      modelId,
      type,
      description: getOptimizationDescription(type),
      startTime: new Date().toISOString(),
      endTime: null,
      status: 'in-progress',
      improvements: {
        accuracyChange: 'pending',
        latencyChange: 'pending'
      }
    };
    
    mockData.optimizations.unshift(newOptimization);
    
    // Add to audit logs
    mockData.auditLogs.unshift({
      id: `log-${mockData.auditLogs.length + 1}`,
      timestamp: new Date().toISOString(),
      action: 'optimization_started',
      description: `Optimization started for ${model.name}`,
      user: 'user'
    });
    
    return true;
  } catch (error) {
    console.error(`Error starting optimization for model ${modelId}:`, error);
    return false;
  }
}

function getOptimizationDescription(type) {
  switch (type) {
    case 'hyperparameter':
      return 'Adjusting hyperparameters for optimal performance';
    case 'retraining':
      return 'Full model retraining with latest data';
    case 'ensemble':
      return 'Creating ensemble with complementary models';
    case 'pruning':
      return 'Model pruning to reduce size and improve latency';
    default:
      return 'Model optimization in progress';
  }
}
