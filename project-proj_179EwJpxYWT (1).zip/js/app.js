// App Component
function App() {
  try {
    const [currentPage, setCurrentPage] = React.useState('dashboard');
    const [sidebarOpen, setSidebarOpen] = React.useState(true);
    const [darkMode, setDarkMode] = React.useState(false);
    
    React.useEffect(() => {
      // Initialize theme from saved preference
      const savedTheme = getThemePreference();
      setDarkMode(savedTheme === 'dark');
      
      // Apply theme
      applyTheme(savedTheme);
    }, []);
    
    const toggleSidebar = () => {
      setSidebarOpen(!sidebarOpen);
    };
    
    const toggleDarkMode = () => {
      const newMode = !darkMode;
      setDarkMode(newMode);
      saveThemePreference(newMode ? 'dark' : 'light');
      applyTheme(newMode ? 'dark' : 'light');
    };
    
    const renderCurrentPage = () => {
      switch(currentPage) {
        case 'dashboard':
          return <Dashboard />;
        case 'models':
          return <Models />;
        case 'analytics':
          return <Analytics />;
        case 'settings':
          return <Settings darkMode={darkMode} toggleDarkMode={toggleDarkMode} />;
        default:
          return <Dashboard />;
      }
    };
    
    return (
      <div data-name="app-container" className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
        <Navigation 
          toggleSidebar={toggleSidebar} 
          darkMode={darkMode} 
          toggleDarkMode={toggleDarkMode} 
        />
        <div data-name="main-content" className="flex">
          <Sidebar 
            isOpen={sidebarOpen} 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage} 
          />
          <main data-name="page-content" className="flex-1 p-4 md:p-6 ml-0 md:ml-64 pt-20">
            {renderCurrentPage()}
          </main>
        </div>
      </div>
    );
  } catch (error) {
    console.error('App render error:', error);
    reportError(error);
    return <div data-name="error-fallback" className="text-center p-10">Something went wrong. Please refresh the page.</div>;
  }
}

// Render the App
const rootElement = document.getElementById('root');
const root = ReactDOM.createRoot(rootElement);
root.render(<App />);
