function OptimizationPanel({ modelId, onStartOptimization, optimizations = [], inProgress = false }) {
  try {
    const [selectedType, setSelectedType] = React.useState('hyperparameter');
    
    const optimizationTypes = [
      { id: 'hyperparameter', name: 'Hyperparameter Tuning', description: 'Optimize model hyperparameters for better performance' },
      { id: 'retraining', name: 'Model Retraining', description: 'Retrain the model with the latest available data' },
      { id: 'ensemble', name: 'Ensemble Creation', description: 'Create an ensemble with complementary models' },
      { id: 'pruning', name: 'Model Pruning', description: 'Reduce model size and improve inference speed' }
    ];
    
    const handleTypeChange = (e) => {
      setSelectedType(e.target.value);
    };
    
    const handleStartOptimization = () => {
      onStartOptimization(modelId, selectedType);
    };
    
    const getLatestOptimization = () => {
      if (optimizations.length === 0) return null;
      return optimizations[0];
    };
    
    const latestOpt = getLatestOptimization();
    
    return (
      <div data-name="optimization-panel">
        <div data-name="optimization-controls" className="mb-4">
          <div data-name="optimization-type" className="mb-3">
            <label data-name="type-label" htmlFor="optimization-type" className="block text-sm font-medium mb-2">
              Optimization Type
            </label>
            <select
              id="optimization-type"
              data-name="type-select"
              className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
              value={selectedType}
              onChange={handleTypeChange}
              disabled={inProgress}
            >
              {optimizationTypes.map(type => (
                <option key={type.id} value={type.id}>
                  {type.name}
                </option>
              ))}
            </select>
            <p data-name="type-description" className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {optimizationTypes.find(t => t.id === selectedType)?.description}
            </p>
          </div>
          
          <button
            data-name="optimize-button"
            className={`w-full py-2 px-4 rounded-md ${
              inProgress ? 
              'bg-slate-400 cursor-not-allowed' : 
              'bg-indigo-600 hover:bg-indigo-700 text-white transition-colors'
            }`}
            onClick={handleStartOptimization}
            disabled={inProgress}
          >
            {inProgress ? (
              <div data-name="optimizing-indicator" className="flex items-center justify-center">
                <i className="fas fa-circle-notch fa-spin mr-2"></i>
                <span>Optimizing...</span>
              </div>
            ) : (
              <span>Start Optimization</span>
            )}
          </button>
        </div>
        
        {latestOpt && (
          <div data-name="latest-optimization" className="mt-4 border-t border-slate-200 dark:border-slate-700 pt-4">
            <h4 data-name="latest-title" className="text-sm font-medium mb-2">Latest Optimization</h4>
            
            <div data-name="latest-details" className="bg-slate-50 dark:bg-slate-700 p-3 rounded-lg">
              <div data-name="latest-header" className="flex justify-between mb-2">
                <span data-name="latest-type" className="font-medium">
                  {latestOpt.type.charAt(0).toUpperCase() + latestOpt.type.slice(1)}
                </span>
                <span data-name="latest-status" className={`text-sm ${
                  latestOpt.status === 'completed' ? 'text-green-600' : 
                  latestOpt.status === 'failed' ? 'text-red-600' : 'text-indigo-600'
                }`}>
                  {latestOpt.status.charAt(0).toUpperCase() + latestOpt.status.slice(1)}
                </span>
              </div>
              
              <p data-name="latest-desc" className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                {latestOpt.description}
              </p>
              
              <div data-name="latest-time" className="text-xs text-slate-500 dark:text-slate-400">
                Started: {formatDate(latestOpt.startTime)}
              </div>
              
              {latestOpt.status === 'completed' && (
                <div data-name="latest-results" className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-600">
                  <div data-name="result-grid" className="grid grid-cols-2 gap-2">
                    <div data-name="accuracy-result" className="text-center">
                      <span data-name="accuracy-label" className="text-xs text-slate-500 block">Accuracy</span>
                      <span data-name="accuracy-value" className={`text-sm font-medium ${
                        latestOpt.improvements.accuracyChange.startsWith('+') ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {latestOpt.improvements.accuracyChange}
                      </span>
                    </div>
                    <div data-name="latency-result" className="text-center">
                      <span data-name="latency-label" className="text-xs text-slate-500 block">Latency</span>
                      <span data-name="latency-value" className={`text-sm font-medium ${
                        latestOpt.improvements.latencyChange.startsWith('-') ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {latestOpt.improvements.latencyChange}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('OptimizationPanel render error:', error);
    reportError(error);
    return <div data-name="optimization-error" className="text-red-600 p-4">Error loading optimization panel.</div>;
  }
}
