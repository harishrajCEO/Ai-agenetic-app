function ModelCard({ model }) {
  try {
    if (!model) return null;
    
    const getStatusIcon = (status) => {
      switch (status) {
        case 'healthy':
          return <i className="fas fa-check-circle text-green-500 mr-1"></i>;
        case 'warning':
          return <i className="fas fa-exclamation-triangle text-yellow-500 mr-1"></i>;
        case 'critical':
          return <i className="fas fa-times-circle text-red-500 mr-1"></i>;
        case 'optimizing':
          return <i className="fas fa-cog fa-spin text-indigo-500 mr-1"></i>;
        default:
          return <i className="fas fa-circle text-slate-400 mr-1"></i>;
      }
    };
    
    const getIndustryIcon = (industry) => {
      switch (industry) {
        case 'healthcare':
          return <i className="fas fa-stethoscope text-blue-500"></i>;
        case 'finance':
          return <i className="fas fa-landmark text-green-500"></i>;
        case 'manufacturing':
          return <i className="fas fa-industry text-yellow-500"></i>;
        case 'telecom':
          return <i className="fas fa-tower-cell text-purple-500"></i>;
        case 'energy':
          return <i className="fas fa-bolt text-red-500"></i>;
        case 'retail':
          return <i className="fas fa-shopping-cart text-pink-500"></i>;
        case 'logistics':
          return <i className="fas fa-truck text-indigo-500"></i>;
        default:
          return <i className="fas fa-robot text-slate-500"></i>;
      }
    };
    
    return (
      <div data-name="model-card" className="model-card bg-white dark:bg-slate-800 rounded-lg shadow p-4">
        <div data-name="model-header" className="flex justify-between items-start mb-3">
          <div data-name="model-title-area" className="flex">
            <div data-name="industry-icon" className="mr-3 mt-1">
              {getIndustryIcon(model.industry)}
            </div>
            <div>
              <h3 data-name="model-name" className="font-medium">{model.name}</h3>
              <p data-name="model-industry" className="text-xs text-slate-500 dark:text-slate-400">
                {model.industry.charAt(0).toUpperCase() + model.industry.slice(1)}
              </p>
            </div>
          </div>
          
          <div data-name="model-status" className={`status-badge status-${model.status.toLowerCase()}`}>
            {getStatusIcon(model.status)}
            <span>{model.status.charAt(0).toUpperCase() + model.status.slice(1)}</span>
          </div>
        </div>
        
        <p data-name="model-desc" className="text-sm text-slate-600 dark:text-slate-300 mb-4 line-clamp-2">
          {model.description}
        </p>
        
        <div data-name="model-metrics" className="grid grid-cols-2 gap-2 mb-2">
          <div data-name="metric-item" className="bg-slate-50 dark:bg-slate-700 p-2 rounded">
            <div data-name="metric-label" className="text-xs text-slate-500 dark:text-slate-400">Accuracy</div>
            <div data-name="metric-value" className="font-medium">{model.accuracy}%</div>
          </div>
          
          <div data-name="metric-item" className="bg-slate-50 dark:bg-slate-700 p-2 rounded">
            <div data-name="metric-label" className="text-xs text-slate-500 dark:text-slate-400">Latency</div>
            <div data-name="metric-value" className="font-medium">{model.latency} ms</div>
          </div>
        </div>
        
        <div data-name="model-footer" className="text-xs text-slate-500 dark:text-slate-400 flex justify-between items-center">
          <span data-name="last-optimized">
            Last optimized: {formatDate(model.lastOptimized)}
          </span>
          
          <a 
            data-name="view-details" 
            href="#" 
            className="text-indigo-600 hover:text-indigo-800 dark:hover:text-indigo-400"
            onClick={(e) => {
              e.preventDefault();
              // In a real app, we'd navigate to the model details page
              console.log('View model details:', model.id);
            }}
          >
            Details
          </a>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ModelCard render error:', error);
    reportError(error);
    return <div data-name="model-card-error" className="text-red-600 p-4">Error loading model card.</div>;
  }
}
