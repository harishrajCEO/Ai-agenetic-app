function AuditLog({ limit = 10 }) {
  try {
    const [logs, setLogs] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    
    React.useEffect(() => {
      fetchLogs();
    }, [limit]);
    
    const fetchLogs = () => {
      try {
        setLoading(true);
        const fetchedLogs = getAuditLogs(limit);
        setLogs(fetchedLogs);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching audit logs:', error);
        setLoading(false);
      }
    };
    
    const getActionIcon = (action) => {
      switch (action) {
        case 'alert_generated':
          return <i className="fas fa-exclamation-triangle text-yellow-500"></i>;
        case 'alert_resolved':
          return <i className="fas fa-check-circle text-green-500"></i>;
        case 'optimization_started':
          return <i className="fas fa-cogs text-indigo-500"></i>;
        case 'optimization_completed':
          return <i className="fas fa-check text-green-500"></i>;
        case 'optimization_failed':
          return <i className="fas fa-times text-red-500"></i>;
        case 'model_updated':
          return <i className="fas fa-robot text-blue-500"></i>;
        case 'settings_changed':
          return <i className="fas fa-sliders-h text-purple-500"></i>;
        default:
          return <i className="fas fa-info-circle text-slate-500"></i>;
      }
    };
    
    if (loading) {
      return (
        <div data-name="audit-log-loading" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4 flex justify-center items-center h-32">
          <div data-name="loading-spinner" className="quark-spin">
            <i className="fas fa-circle-notch text-indigo-600 text-2xl"></i>
          </div>
        </div>
      );
    }
    
    if (logs.length === 0) {
      return (
        <div data-name="no-logs" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4 text-center">
          <p data-name="no-logs-message">No audit logs available.</p>
        </div>
      );
    }
    
    return (
      <div data-name="audit-log" className="bg-white dark:bg-slate-800 rounded-lg shadow">
        {logs.map((log) => (
          <div data-name="audit-log-entry" key={log.id} className="audit-log-entry">
            <div data-name="log-content" className="flex items-start">
              <div data-name="log-icon" className="mr-3 mt-1">
                {getActionIcon(log.action)}
              </div>
              <div data-name="log-details" className="flex-1">
                <div data-name="log-description" className="text-sm font-medium">
                  {log.description}
                </div>
                <div data-name="log-meta" className="flex justify-between mt-1">
                  <span data-name="log-timestamp" className="text-xs text-slate-500">
                    {formatDate(log.timestamp)}
                  </span>
                  <span data-name="log-user" className="text-xs text-slate-500">
                    {log.user === 'system' ? 
                      <span data-name="system-tag" className="bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">System</span> : 
                      <span data-name="user-name">{log.user}</span>
                    }
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  } catch (error) {
    console.error('AuditLog render error:', error);
    reportError(error);
    return <div data-name="audit-log-error" className="text-red-600 p-4">Error loading audit logs.</div>;
  }
}
