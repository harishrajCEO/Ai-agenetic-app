function NearWalletConnection({ nearConnection, onConnect, onDisconnect }) {
  try {
    const [isConnecting, setIsConnecting] = React.useState(false);
    const [isSignedIn, setIsSignedIn] = React.useState(false);
    const [accountId, setAccountId] = React.useState('');
    const [accountBalance, setAccountBalance] = React.useState('');
    const [error, setError] = React.useState(null);
    
    // Check if wallet is connected on component mount
    React.useEffect(() => {
      if (nearConnection) {
        const walletSignedIn = nearConnection.walletConnection && nearConnection.walletConnection.isSignedIn();
        setIsSignedIn(walletSignedIn);
        
        if (walletSignedIn) {
          setAccountId(nearConnection.accountId);
          fetchAccountBalance(nearConnection);
        }
      }
    }, [nearConnection]);
    
    // Fetch account balance
    const fetchAccountBalance = async (connection) => {
      try {
        if (connection && connection.walletConnection && connection.walletConnection.isSignedIn()) {
          const account = connection.walletConnection.account();
          const balance = await account.getAccountBalance();
          
          // Format balance to show in NEAR with 2 decimal places
          const formattedBalance = parseFloat(
            nearApi.utils.format.formatNearAmount(balance.available, 2)
          ).toFixed(2);
          
          setAccountBalance(formattedBalance);
        }
      } catch (err) {
        console.error('Error fetching account balance:', err);
        reportError(err);
        setAccountBalance('Error');
      }
    };
    
    // Connect to NEAR wallet
    const handleConnect = async () => {
      try {
        setIsConnecting(true);
        setError(null);
        
        if (!nearConnection) {
          throw new Error('NEAR connection not initialized');
        }
        
        // Request sign in
        await loginToNear(nearConnection.walletConnection);
        
        // The page will redirect to NEAR wallet for authentication
        // After authentication, it will redirect back to our app
        
        // We won't reach this code until after redirect back
        setIsConnecting(false);
        
        if (onConnect) {
          onConnect();
        }
      } catch (err) {
        console.error('Error connecting to NEAR wallet:', err);
        reportError(err);
        setError('Failed to connect to NEAR wallet. Please try again.');
        setIsConnecting(false);
      }
    };
    
    // Disconnect from NEAR wallet
    const handleDisconnect = () => {
      try {
        if (nearConnection && nearConnection.walletConnection) {
          logoutFromNear(nearConnection.walletConnection);
          setIsSignedIn(false);
          setAccountId('');
          setAccountBalance('');
          
          if (onDisconnect) {
            onDisconnect();
          }
        }
      } catch (err) {
        console.error('Error disconnecting from NEAR wallet:', err);
        reportError(err);
        setError('Failed to disconnect from NEAR wallet. Please try again.');
      }
    };
    
    // Format account ID for display (truncate if too long)
    const formatAccountId = (id) => {
      if (!id) return '';
      if (id.length <= 16) return id;
      return `${id.substring(0, 8)}...${id.substring(id.length - 4)}`;
    };
    
    return (
      <div data-name="near-wallet-connection" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
        <div data-name="wallet-header" className="flex justify-between items-center mb-4">
          <h3 data-name="wallet-title" className="text-lg font-semibold">NEAR Wallet</h3>
          <div data-name="near-logo" className="w-6 h-6">
            <img 
              src="https://near.org/wp-content/themes/near-19/assets/img/brand-icon.png" 
              alt="NEAR Protocol" 
              className="w-full h-full"
            />
          </div>
        </div>
        
        {error && (
          <div data-name="wallet-error" className="mb-4 p-3 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-sm">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            {error}
          </div>
        )}
        
        {!isSignedIn ? (
          <div data-name="wallet-connect">
            <p data-name="wallet-description" className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Connect your NEAR wallet to vote on quantum swaps and store model data on the blockchain.
            </p>
            
            <button
              data-name="connect-button"
              className={`w-full py-2 px-4 rounded-md ${
                isConnecting 
                ? 'bg-slate-400 dark:bg-slate-600 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-700 text-white transition-colors'
              }`}
              onClick={handleConnect}
              disabled={isConnecting}
            >
              {isConnecting ? (
                <div data-name="connecting-indicator" className="flex items-center justify-center">
                  <i className="fas fa-circle-notch fa-spin mr-2"></i>
                  <span>Connecting...</span>
                </div>
              ) : (
                <div data-name="connect-text" className="flex items-center justify-center">
                  <i className="fas fa-wallet mr-2"></i>
                  <span>Connect NEAR Wallet</span>
                </div>
              )}
            </button>
            
            <div data-name="wallet-note" className="mt-4 text-xs text-slate-500 dark:text-slate-400 text-center">
              <p>Don't have a NEAR wallet?</p>
              <a 
                href="https://wallet.testnet.near.org/create" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-800 dark:hover:text-indigo-400"
              >
                Create one on NEAR Testnet
              </a>
            </div>
          </div>
        ) : (
          <div data-name="wallet-info">
            <div data-name="account-details" className="mb-4">
              <div data-name="account-id" className="flex justify-between items-center mb-2">
                <span data-name="account-label" className="text-sm text-slate-500 dark:text-slate-400">Account ID:</span>
                <span data-name="account-value" className="font-medium">{formatAccountId(accountId)}</span>
              </div>
              
              <div data-name="account-balance" className="flex justify-between items-center">
                <span data-name="balance-label" className="text-sm text-slate-500 dark:text-slate-400">Balance:</span>
                <span data-name="balance-value" className="font-medium">
                  {accountBalance ? `${accountBalance} NEAR` : 'Loading...'}
                </span>
              </div>
            </div>
            
            <div data-name="network-info" className="mb-4 p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
              <div data-name="network-header" className="flex justify-between items-center mb-2">
                <span data-name="network-label" className="text-sm font-medium">Network:</span>
                <span data-name="network-badge" className="px-2 py-1 text-xs bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 rounded-full">
                  Testnet
                </span>
              </div>
              
              <div data-name="contract-id" className="text-xs text-slate-500 dark:text-slate-400">
                Contract: {nearConfig.contractName}
              </div>
            </div>
            
            <button
              data-name="disconnect-button"
              className="w-full py-2 px-4 border border-slate-300 dark:border-slate-600 rounded-md hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
              onClick={handleDisconnect}
            >
              <div data-name="disconnect-text" className="flex items-center justify-center">
                <i className="fas fa-sign-out-alt mr-2"></i>
                <span>Disconnect Wallet</span>
              </div>
            </button>
          </div>
        )}
      </div>
    );
  } catch (error) {
    console.error('NearWalletConnection render error:', error);
    reportError(error);
    return <div data-name="wallet-error" className="text-red-600 p-4">Error loading NEAR wallet connection.</div>;
  }
}
