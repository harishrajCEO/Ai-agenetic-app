function AddModelModal({ onClose, onAddModel, industries = [] }) {
  try {
    const [modelName, setModelName] = React.useState('');
    const [industry, setIndustry] = React.useState(industries.length > 0 ? industries[0].id : '');
    const [description, setDescription] = React.useState('');
    const [accuracy, setAccuracy] = React.useState(90);
    const [latency, setLatency] = React.useState(100);
    const [isAbsurd, setIsAbsurd] = React.useState(false);
    const [generating, setGenerating] = React.useState(false);
    const [error, setError] = React.useState(null);
    
    // Default industries if none provided
    const defaultIndustries = [
      { id: 'healthcare', name: 'Healthcare' },
      { id: 'finance', name: 'Finance' },
      { id: 'manufacturing', name: 'Manufacturing' },
      { id: 'telecom', name: 'Telecom' },
      { id: 'energy', name: 'Energy' },
      { id: 'retail', name: 'Retail' },
      { id: 'logistics', name: 'Logistics' }
    ];
    
    const industryOptions = industries.length > 0 ? industries : defaultIndustries;
    
    // Generate absurd model
    const generateAbsurdModel = () => {
      setGenerating(true);
      
      // Simulate generation delay
      setTimeout(() => {
        try {
          const model = {
            industry,
            status: 'healthy'
          };
          
          // Generate absurd name and description
          const absurdModel = window.generateAbsurdModel(model);
          
          if (absurdModel) {
            setModelName(absurdModel.name);
            setDescription(absurdModel.description);
            setAccuracy(absurdModel.accuracy);
            setLatency(absurdModel.latency);
            setIsAbsurd(true);
          }
          
          setGenerating(false);
        } catch (err) {
          console.error('Error generating absurd model:', err);
          reportError(err);
          setError('Failed to generate absurd model. Please try again.');
          setGenerating(false);
        }
      }, 1000);
    };
    
    // Handle form submission
    const handleSubmit = (e) => {
      e.preventDefault();
      
      try {
        // Validate inputs
        if (!modelName.trim()) {
          setError('Model name is required');
          return;
        }
        
        if (!industry) {
          setError('Please select an industry');
          return;
        }
        
        if (!description.trim()) {
          setError('Description is required');
          return;
        }
        
        // Create model object
        const newModel = {
          id: `model-${Date.now()}`,
          name: modelName.trim(),
          industry,
          description: description.trim(),
          accuracy: parseFloat(accuracy),
          latency: parseFloat(latency),
          status: 'healthy',
          lastOptimized: new Date().toISOString(),
          isAbsurd,
          metrics: {
            precision: accuracy / 100 - 0.02,
            recall: accuracy / 100 - 0.03,
            f1Score: accuracy / 100 - 0.025,
            resourceUsage: 50 + Math.random() * 30
          }
        };
        
        // Add model
        onAddModel(newModel);
        
        // Close modal
        onClose();
      } catch (err) {
        console.error('Error adding model:', err);
        reportError(err);
        setError('Failed to add model. Please try again.');
      }
    };
    
    return (
      <div data-name="add-model-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div data-name="modal-container" className="bg-white dark:bg-slate-800 rounded-lg shadow-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
          <div data-name="modal-header" className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
            <h2 data-name="modal-title" className="text-xl font-semibold">Add New AI Model</h2>
            <button 
              data-name="close-button" 
              className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
              onClick={onClose}
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
          
          <form data-name="add-model-form" onSubmit={handleSubmit}>
            <div data-name="modal-body" className="p-4">
              {error && (
                <div data-name="form-error" className="mb-4 p-3 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-sm">
                  <i className="fas fa-exclamation-triangle mr-2"></i>
                  {error}
                </div>
              )}
              
              <div data-name="form-group" className="mb-4">
                <label data-name="name-label" className="block text-sm font-medium mb-1" htmlFor="model-name">
                  Model Name
                </label>
                <input
                  id="model-name"
                  data-name="name-input"
                  type="text"
                  className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  placeholder="Enter model name"
                />
              </div>
              
              <div data-name="form-group" className="mb-4">
                <label data-name="industry-label" className="block text-sm font-medium mb-1" htmlFor="industry-select">
                  Industry
                </label>
                <select
                  id="industry-select"
                  data-name="industry-select"
                  className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                >
                  {industryOptions.map(ind => (
                    <option key={ind.id} value={ind.id}>{ind.name}</option>
                  ))}
                </select>
              </div>
              
              <div data-name="form-group" className="mb-4">
                <label data-name="description-label" className="block text-sm font-medium mb-1" htmlFor="model-description">
                  Description
                </label>
                <textarea
                  id="model-description"
                  data-name="description-input"
                  className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700 min-h-[100px]"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter model description"
                ></textarea>
              </div>
              
              <div data-name="metrics-row" className="grid grid-cols-2 gap-4 mb-4">
                <div data-name="form-group">
                  <label data-name="accuracy-label" className="block text-sm font-medium mb-1" htmlFor="model-accuracy">
                    Accuracy (%)
                  </label>
                  <input
                    id="model-accuracy"
                    data-name="accuracy-input"
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                    value={accuracy}
                    onChange={(e) => setAccuracy(e.target.value)}
                  />
                </div>
                
                <div data-name="form-group">
                  <label data-name="latency-label" className="block text-sm font-medium mb-1" htmlFor="model-latency">
                    Latency (ms)
                  </label>
                  <input
                    id="model-latency"
                    data-name="latency-input"
                    type="number"
                    min="1"
                    className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700"
                    value={latency}
                    onChange={(e) => setLatency(e.target.value)}
                  />
                </div>
              </div>
              
              <div data-name="absurd-generator" className="mb-4 p-3 bg-slate-50 dark:bg-slate-700 rounded-lg">
                <div data-name="absurd-header" className="flex justify-between items-center mb-2">
                  <h3 data-name="absurd-title" className="text-sm font-medium">Quantum Absurdity Generator</h3>
                  <div data-name="absurd-badge" className="px-2 py-1 text-xs bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300 rounded-full">
                    Experimental
                  </div>
                </div>
                
                <p data-name="absurd-description" className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Generate an absurd, quantum-inspired AI model with unexpected capabilities
                </p>
                
                <button
                  type="button"
                  data-name="generate-button"
                  className="w-full py-2 flex items-center justify-center text-sm bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded hover:from-indigo-600 hover:to-purple-700"
                  onClick={generateAbsurdModel}
                  disabled={generating}
                >
                  {generating ? (
                    <div data-name="generating-indicator" className="flex items-center">
                      <i className="fas fa-circle-notch fa-spin mr-2"></i>
                      <span>Generating Absurdity...</span>
                    </div>
                  ) : (
                    <div data-name="generate-text" className="flex items-center">
                      <i className="fas fa-magic mr-2"></i>
                      <span>Generate Absurd Model</span>
                    </div>
                  )}
                </button>
              </div>
            </div>
            
            <div data-name="modal-footer" className="p-4 border-t border-slate-200 dark:border-slate-700 flex justify-end">
              <button
                type="button"
                data-name="cancel-button"
                className="px-4 py-2 mr-2 border border-slate-300 dark:border-slate-600 rounded hover:bg-slate-100 dark:hover:bg-slate-700"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                type="submit"
                data-name="add-button"
                className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              >
                Add Model
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AddModelModal render error:', error);
    reportError(error);
    return <div data-name="modal-error" className="text-red-600 p-4">Error loading modal. Please try again.</div>;
  }
}
