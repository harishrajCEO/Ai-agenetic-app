function Navigation({ toggleSidebar, darkMode, toggleDarkMode }) {
  try {
    return (
      <header data-name="main-header" className="fixed top-0 left-0 right-0 z-20 bg-white dark:bg-slate-800 shadow-sm">
        <div data-name="header-container" className="flex items-center justify-between h-16 px-4">
          <div data-name="header-left" className="flex items-center">
            <button
              data-name="sidebar-toggle"
              className="p-2 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 md:hidden"
              onClick={toggleSidebar}
            >
              <i className="fas fa-bars"></i>
            </button>
            
            <div data-name="logo-container" className="ml-2 md:ml-0 flex items-center">
              <div data-name="logo-icon" className="flex items-center justify-center w-8 h-8 rounded-md quantum-gradient text-white mr-2">
                <i className="fas fa-atom"></i>
              </div>
              <h1 data-name="app-name" className="text-xl font-bold">AI Agenetic</h1>
            </div>
          </div>
          
          <div data-name="header-right" className="flex items-center space-x-4">
            <button
              data-name="theme-toggle"
              className="p-2 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
              onClick={toggleDarkMode}
              title="Toggle dark mode"
            >
              {darkMode ? (
                <i className="fas fa-sun"></i>
              ) : (
                <i className="fas fa-moon"></i>
              )}
            </button>
            
            <div data-name="user-menu" className="relative">
              <button
                data-name="user-button"
                className="flex items-center p-1 rounded-full border border-slate-300 dark:border-slate-600"
              >
                <div data-name="user-avatar" className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white">
                  <span data-name="user-initials">AD</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Navigation render error:', error);
    reportError(error);
    return <div data-name="navigation-error" className="text-red-600 p-4">Error loading navigation.</div>;
  }
}
