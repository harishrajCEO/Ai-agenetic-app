function QuantumSwapVoting({ models = [], nearConnection = null }) {
  try {
    const [votingPairs, setVotingPairs] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [voting, setVoting] = React.useState(false);
    const [votingResults, setVotingResults] = React.useState(null);
    const [error, setError] = React.useState(null);
    
    // Initialize voting pairs
    React.useEffect(() => {
      if (models.length > 1) {
        setLoading(true);
        
        // Generate potential model pairs for quantum swapping
        const pairs = generateVotingPairs(models);
        setVotingPairs(pairs);
        
        // Fetch existing voting results if NEAR connection is available
        if (nearConnection && nearConnection.contract) {
          fetchVotingResults(nearConnection.contract);
        } else {
          // If no NEAR connection, use mock data
          setTimeout(() => {
            const mockResults = generateMockVotingResults(pairs);
            setVotingResults(mockResults);
            setLoading(false);
          }, 1000);
        }
      } else {
        setLoading(false);
      }
    }, [models, nearConnection]);
    
    // Generate potential model pairs for quantum swapping
    const generateVotingPairs = (models) => {
      const pairs = [];
      
      // Find models that aren't already entangled
      const swappableModels = models.filter(m => !m.entangledWith && m.status !== 'optimizing');
      
      // Only proceed if we have at least 2 swappable models
      if (swappableModels.length < 2) return pairs;
      
      // Generate all possible pairs and calculate affinity
      for (let i = 0; i < swappableModels.length; i++) {
        for (let j = i + 1; j < swappableModels.length; j++) {
          const source = swappableModels[i];
          const target = swappableModels[j];
          
          // Calculate quantum affinity between models
          const affinity = calculateQuantumAffinity(source, target);
          
          // Only include pairs with decent affinity
          if (affinity > 0.5) {
            pairs.push({
              id: `${source.id}-${target.id}`,
              sourceModel: source,
              targetModel: target,
              affinity,
              votes: 0,
              expectedImprovements: {
                sourceAccuracy: (Math.random() * 5).toFixed(1),
                targetAccuracy: (Math.random() * 5).toFixed(1),
                sourceLatency: (Math.random() * -15).toFixed(0),
                targetLatency: (Math.random() * -15).toFixed(0)
              }
            });
          }
        }
      }
      
      // Sort by affinity (highest first)
      return pairs.sort((a, b) => b.affinity - a.affinity).slice(0, 5); // Limit to top 5
    };
    
    // Fetch voting results from NEAR contract
    const fetchVotingResults = async (contract) => {
      try {
        const results = await getQuantumSwapVotes(contract);
        setVotingResults(results);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching voting results:', err);
        reportError(err);
        setError('Failed to fetch voting results from the blockchain');
        setLoading(false);
      }
    };
    
    // Generate mock voting results for development
    const generateMockVotingResults = (pairs) => {
      return pairs.map(pair => ({
        pairId: pair.id,
        votes: Math.floor(Math.random() * 20),
        lastVoted: new Date(Date.now() - Math.random() * 86400000).toISOString() // Random time in last 24 hours
      }));
    };
    
    // Vote for a model pair
    const handleVote = async (pairId) => {
      setVoting(true);
      
      try {
        // Find the pair
        const pair = votingPairs.find(p => p.id === pairId);
        
        if (!pair) {
          throw new Error('Pair not found');
        }
        
        // If we have NEAR connection, vote on chain
        if (nearConnection && nearConnection.contract && nearConnection.walletConnection.isSignedIn()) {
          await voteForQuantumSwap(
            nearConnection.contract, 
            pair.sourceModel.id, 
            pair.targetModel.id
          );
          
          // Refresh voting results
          await fetchVotingResults(nearConnection.contract);
        } else {
          // Mock voting for development
          setTimeout(() => {
            setVotingResults(prev => 
              prev.map(result => 
                result.pairId === pairId 
                  ? { ...result, votes: result.votes + 1, lastVoted: new Date().toISOString() }
                  : result
              )
            );
            setVoting(false);
          }, 1000);
        }
      } catch (err) {
        console.error('Error voting:', err);
        reportError(err);
        setError('Failed to submit vote. Please try again.');
        setVoting(false);
      }
    };
    
    // Format affinity as percentage
    const formatAffinity = (affinity) => {
      return `${(affinity * 100).toFixed(0)}%`;
    };
    
    if (loading) {
      return (
        <div data-name="quantum-voting-loading" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
          <div data-name="loading-header" className="flex justify-between items-center mb-4">
            <h3 data-name="loading-title" className="text-lg font-semibold">Quantum Swap Voting</h3>
            <div data-name="loading-spinner" className="quark-spin">
              <i className="fas fa-circle-notch text-indigo-600 text-xl"></i>
            </div>
          </div>
          <div data-name="loading-skeleton" className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-24 bg-slate-200 dark:bg-slate-700 rounded animate-pulse"></div>
            ))}
          </div>
        </div>
      );
    }
    
    if (error) {
      return (
        <div data-name="quantum-voting-error" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
          <div data-name="error-header" className="flex justify-between items-center mb-4">
            <h3 data-name="error-title" className="text-lg font-semibold">Quantum Swap Voting</h3>
            <button 
              data-name="retry-button"
              className="text-indigo-600 hover:text-indigo-800 dark:hover:text-indigo-400"
              onClick={() => {
                setError(null);
                setLoading(true);
                if (nearConnection && nearConnection.contract) {
                  fetchVotingResults(nearConnection.contract);
                } else {
                  const mockResults = generateMockVotingResults(votingPairs);
                  setVotingResults(mockResults);
                  setLoading(false);
                }
              }}
            >
              <i className="fas fa-sync-alt"></i>
            </button>
          </div>
          <div data-name="error-message" className="bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-4 rounded-lg">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            {error}
          </div>
        </div>
      );
    }
    
    if (votingPairs.length === 0) {
      return (
        <div data-name="no-voting-pairs" className="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
          <h3 data-name="no-pairs-title" className="text-lg font-semibold mb-4">Quantum Swap Voting</h3>
          <div data-name="no-pairs-message" className="text-center p-6">
            <i className="fas fa-atom text-slate-400 text-4xl mb-3"></i>
            <p data-name="no-pairs-text" className="text-slate-500 dark:text-slate-400">
              No eligible model pairs found for quantum swapping.
              <br />
              Models need to be unentangled and have sufficient quantum affinity.
            </p>
          </div>
        </div>
      );
    }
    
    return (
      <div data-name="quantum-swap-voting" className="bg-white dark:bg-slate-800 rounded-lg shadow">
        <div data-name="voting-header" className="p-4 border-b border-slate-200 dark:border-slate-700">
          <h3 data-name="voting-title" className="text-lg font-semibold">Quantum Swap Voting</h3>
          <p data-name="voting-description" className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Vote for model pairs to undergo quantum parameter swapping
          </p>
        </div>
        
        <div data-name="voting-pairs" className="divide-y divide-slate-200 dark:divide-slate-700">
          {votingPairs.map(pair => {
            // Find voting result for this pair
            const result = votingResults?.find(r => r.pairId === pair.id);
            const voteCount = result?.votes || 0;
            
            return (
              <div 
                key={pair.id} 
                data-name="voting-pair-item"
                className="p-4"
              >
                <div data-name="pair-header" className="flex justify-between items-start mb-3">
                  <div data-name="models-info">
                    <div data-name="models-names" className="font-medium">
                      {pair.sourceModel.name} + {pair.targetModel.name}
                    </div>
                    <div data-name="models-industries" className="text-xs text-slate-500 dark:text-slate-400">
                      {pair.sourceModel.industry.charAt(0).toUpperCase() + pair.sourceModel.industry.slice(1)} + 
                      {' '}{pair.targetModel.industry.charAt(0).toUpperCase() + pair.targetModel.industry.slice(1)}
                    </div>
                  </div>
                  <div data-name="affinity-badge" className="px-2 py-1 text-xs rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300">
                    <i className="fas fa-atom mr-1"></i>
                    Affinity: {formatAffinity(pair.affinity)}
                  </div>
                </div>
                
                <div data-name="expected-improvements" className="grid grid-cols-2 gap-3 mb-3">
                  <div data-name="source-improvements" className="bg-slate-50 dark:bg-slate-700 p-2 rounded-lg">
                    <div data-name="source-header" className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                      {pair.sourceModel.name}
                    </div>
                    <div data-name="source-metrics" className="grid grid-cols-2 gap-2">
                      <div data-name="accuracy-change" className="text-xs">
                        <span className="text-green-600 dark:text-green-400">+{pair.expectedImprovements.sourceAccuracy}%</span> Accuracy
                      </div>
                      <div data-name="latency-change" className="text-xs">
                        <span className="text-green-600 dark:text-green-400">{pair.expectedImprovements.sourceLatency}ms</span> Latency
                      </div>
                    </div>
                  </div>
                  
                  <div data-name="target-improvements" className="bg-slate-50 dark:bg-slate-700 p-2 rounded-lg">
                    <div data-name="target-header" className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                      {pair.targetModel.name}
                    </div>
                    <div data-name="target-metrics" className="grid grid-cols-2 gap-2">
                      <div data-name="accuracy-change" className="text-xs">
                        <span className="text-green-600 dark:text-green-400">+{pair.expectedImprovements.targetAccuracy}%</span> Accuracy
                      </div>
                      <div data-name="latency-change" className="text-xs">
                        <span className="text-green-600 dark:text-green-400">{pair.expectedImprovements.targetLatency}ms</span> Latency
                      </div>
                    </div>
                  </div>
                </div>
                
                <div data-name="voting-controls" className="flex justify-between items-center">
                  <div data-name="vote-count" className="flex items-center">
                    <i className="fas fa-vote-yea text-indigo-500 mr-2"></i>
                    <span className="font-medium">{voteCount}</span>
                    <span className="text-slate-500 dark:text-slate-400 ml-1">votes</span>
                  </div>
                  
                  <button
                    data-name="vote-button"
                    className={`px-4 py-1 text-sm rounded ${
                      voting 
                      ? 'bg-slate-300 dark:bg-slate-600 cursor-not-allowed' 
                      : 'bg-indigo-100 text-indigo-800 hover:bg-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300 dark:hover:bg-indigo-800/40'
                    }`}
                    onClick={() => handleVote(pair.id)}
                    disabled={voting}
                  >
                    {voting ? (
                      <div data-name="voting-spinner" className="flex items-center">
                        <i className="fas fa-circle-notch fa-spin mr-2"></i>
                        Voting...
                      </div>
                    ) : (
                      <div data-name="vote-text" className="flex items-center">
                        <i className="fas fa-atom mr-2"></i>
                        Vote for Swap
                      </div>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        
        <div data-name="voting-footer" className="p-4 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400 flex justify-between items-center">
          <div data-name="voting-note">
            Votes are recorded on the NEAR blockchain
          </div>
          <div data-name="refresh-button">
            <button 
              data-name="refresh-voting"
              className="text-indigo-600 hover:text-indigo-800 dark:hover:text-indigo-400"
              onClick={() => {
                setLoading(true);
                if (nearConnection && nearConnection.contract) {
                  fetchVotingResults(nearConnection.contract);
                } else {
                  setTimeout(() => {
                    const mockResults = generateMockVotingResults(votingPairs);
                    setVotingResults(mockResults);
                    setLoading(false);
                  }, 1000);
                }
              }}
            >
              <i className="fas fa-sync-alt mr-1"></i>
              Refresh Results
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('QuantumSwapVoting render error:', error);
    reportError(error);
    return <div data-name="voting-error" className="text-red-600 p-4">Error loading quantum swap voting.</div>;
  }
}
