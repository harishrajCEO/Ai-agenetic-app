function ModelRegistry({ models, selectedModelId, onModelSelect }) {
  try {
    const handleModelClick = (model) => {
      onModelSelect(model);
    };
    
    if (models.length === 0) {
      return (
        <div data-name="no-models" className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 text-center">
          <i className="fas fa-robot text-4xl text-slate-400 mb-3"></i>
          <p data-name="no-models-message" className="text-slate-500 dark:text-slate-400">
            No AI models found in the registry.
          </p>
        </div>
      );
    }
    
    return (
      <div data-name="model-registry" className="bg-white dark:bg-slate-800 rounded-lg shadow">
        <div data-name="registry-header" className="p-4 border-b border-slate-200 dark:border-slate-700">
          <h3 data-name="registry-title" className="font-semibold">Model Registry</h3>
          <p data-name="registry-count" className="text-sm text-slate-500 dark:text-slate-400">
            {models.length} model{models.length !== 1 ? 's' : ''}
          </p>
        </div>
        
        <div data-name="models-list" className="divide-y divide-slate-200 dark:divide-slate-700">
          {models.map(model => (
            <div
              data-name="model-list-item"
              key={model.id}
              className={`p-4 cursor-pointer transition-colors ${
                selectedModelId === model.id ? 
                'bg-indigo-50 dark:bg-indigo-900/20' : 
                'hover:bg-slate-50 dark:hover:bg-slate-700/30'
              }`}
              onClick={() => handleModelClick(model)}
            >
              <div data-name="model-header" className="flex justify-between items-start">
                <h4 data-name="model-name" className="font-medium">{model.name}</h4>
                <div data-name="model-status" className={`status-badge status-${model.status.toLowerCase()}`}>
                  {model.status.charAt(0).toUpperCase() + model.status.slice(1)}
                </div>
              </div>
              
              <div data-name="model-meta" className="mt-2 flex items-center text-sm text-slate-500 dark:text-slate-400">
                <div data-name="model-industry" className="flex items-center mr-4">
                  <i className="fas fa-building mr-1"></i>
                  <span>{model.industry.charAt(0).toUpperCase() + model.industry.slice(1)}</span>
                </div>
                
                <div data-name="model-accuracy" className="flex items-center">
                  <i className="fas fa-chart-line mr-1"></i>
                  <span>{model.accuracy}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('ModelRegistry render error:', error);
    reportError(error);
    return <div data-name="registry-error" className="text-red-600 p-4">Error loading model registry.</div>;
  }
}
