function PerformanceMetrics({ models = [] }) {
  try {
    // Calculate aggregate metrics across all models
    const calculateAggregateMetrics = () => {
      if (models.length === 0) return null;
      
      const totalModels = models.length;
      const healthyModels = models.filter(m => m.status === 'healthy').length;
      const avgAccuracy = models.reduce((sum, model) => sum + model.accuracy, 0) / totalModels;
      const avgLatency = models.reduce((sum, model) => sum + model.latency, 0) / totalModels;
      const totalResourceUsage = models.reduce((sum, model) => sum + model.metrics.resourceUsage, 0);
      const avgResourceUsage = totalResourceUsage / totalModels;
      
      return {
        totalModels,
        healthyModels,
        healthPercentage: (healthyModels / totalModels) * 100,
        avgAccuracy,
        avgLatency,
        avgResourceUsage
      };
    };
    
    const aggregateMetrics = calculateAggregateMetrics();
    
    if (!aggregateMetrics) {
      return (
        <div data-name="no-metrics" className="text-center p-6 bg-white dark:bg-slate-800 rounded-lg shadow">
          <p data-name="no-metrics-message" className="text-slate-500 dark:text-slate-400">
            No model data available to display metrics.
          </p>
        </div>
      );
    }
    
    return (
      <div data-name="performance-metrics" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div data-name="metric-card" className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow">
          <div data-name="metric-header" className="flex items-center justify-between mb-2">
            <h3 data-name="metric-title" className="text-sm font-medium text-slate-500 dark:text-slate-400">Model Health</h3>
            <i className="fas fa-heartbeat text-indigo-500"></i>
          </div>
          
          <div data-name="metric-value" className="text-2xl font-bold mb-1">
            {aggregateMetrics.healthPercentage.toFixed(1)}%
          </div>
          
          <div data-name="metric-info" className="text-xs text-slate-500 dark:text-slate-400">
            {aggregateMetrics.healthyModels} of {aggregateMetrics.totalModels} models healthy
          </div>
          
          <div data-name="progress-container" className="mt-2">
            <div data-name="progress-bar" className="progress-bar">
              <div 
                data-name="progress-bar-fill" 
                className="progress-bar-fill" 
                style={{ 
                  width: `${aggregateMetrics.healthPercentage}%`,
                  backgroundColor: getProgressColor(aggregateMetrics.healthPercentage)
                }}
              ></div>
            </div>
          </div>
        </div>
        
        <div data-name="metric-card" className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow">
          <div data-name="metric-header" className="flex items-center justify-between mb-2">
            <h3 data-name="metric-title" className="text-sm font-medium text-slate-500 dark:text-slate-400">Average Accuracy</h3>
            <i className="fas fa-bullseye text-indigo-500"></i>
          </div>
          
          <div data-name="metric-value" className="text-2xl font-bold mb-1">
            {aggregateMetrics.avgAccuracy.toFixed(1)}%
          </div>
          
          <div data-name="metric-info" className="text-xs text-slate-500 dark:text-slate-400">
            Across all models
          </div>
          
          <div data-name="progress-container" className="mt-2">
            <div data-name="progress-bar" className="progress-bar">
              <div 
                data-name="progress-bar-fill" 
                className="progress-bar-fill" 
                style={{ 
                  width: `${aggregateMetrics.avgAccuracy}%`,
                  backgroundColor: getProgressColor(aggregateMetrics.avgAccuracy)
                }}
              ></div>
            </div>
          </div>
        </div>
        
        <div data-name="metric-card" className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow">
          <div data-name="metric-header" className="flex items-center justify-between mb-2">
            <h3 data-name="metric-title" className="text-sm font-medium text-slate-500 dark:text-slate-400">Average Latency</h3>
            <i className="fas fa-tachometer-alt text-indigo-500"></i>
          </div>
          
          <div data-name="metric-value" className="text-2xl font-bold mb-1">
            {aggregateMetrics.avgLatency.toFixed(0)} ms
          </div>
          
          <div data-name="metric-info" className="text-xs text-slate-500 dark:text-slate-400">
            Response time
          </div>
          
          <div data-name="progress-container" className="mt-2">
            <div data-name="progress-bar" className="progress-bar">
              <div 
                data-name="progress-bar-fill" 
                className="progress-bar-fill" 
                style={{ 
                  width: `${Math.min(aggregateMetrics.avgLatency / 2, 100)}%`,
                  backgroundColor: getLatencyColor(aggregateMetrics.avgLatency)
                }}
              ></div>
            </div>
          </div>
        </div>
        
        <div data-name="metric-card" className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow">
          <div data-name="metric-header" className="flex items-center justify-between mb-2">
            <h3 data-name="metric-title" className="text-sm font-medium text-slate-500 dark:text-slate-400">Resource Usage</h3>
            <i className="fas fa-server text-indigo-500"></i>
          </div>
          
          <div data-name="metric-value" className="text-2xl font-bold mb-1">
            {aggregateMetrics.avgResourceUsage.toFixed(0)}%
          </div>
          
          <div data-name="metric-info" className="text-xs text-slate-500 dark:text-slate-400">
            Average CPU/memory utilization
          </div>
          
          <div data-name="progress-container" className="mt-2">
            <div data-name="progress-bar" className="progress-bar">
              <div 
                data-name="progress-bar-fill" 
                className="progress-bar-fill" 
                style={{ 
                  width: `${aggregateMetrics.avgResourceUsage}%`,
                  backgroundColor: getResourceColor(aggregateMetrics.avgResourceUsage)
                }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('PerformanceMetrics render error:', error);
    reportError(error);
    return <div data-name="metrics-error" className="text-red-600 p-4">Error loading performance metrics.</div>;
  }
}

// Helper functions for colors
function getProgressColor(value) {
  if (value >= 90) return '#10b981'; // green
  if (value >= 75) return '#6366f1'; // indigo
  if (value >= 60) return '#f59e0b'; // yellow
  return '#ef4444'; // red
}

function getLatencyColor(value) {
  if (value <= 50) return '#10b981'; // green
  if (value <= 100) return '#6366f1'; // indigo
  if (value <= 150) return '#f59e0b'; // yellow
  return '#ef4444'; // red
}

function getResourceColor(value) {
  if (value <= 50) return '#10b981'; // green
  if (value <= 70) return '#6366f1'; // indigo
  if (value <= 85) return '#f59e0b'; // yellow
  return '#ef4444'; // red
}
