function Sidebar({ isOpen, currentPage, setCurrentPage }) {
  try {
    const navItems = [
      { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-line' },
      { id: 'models', label: 'Models', icon: 'fa-robot' },
      { id: 'analytics', label: 'Analytics', icon: 'fa-chart-bar' },
      { id: 'settings', label: 'Settings', icon: 'fa-cog' }
    ];
    
    const handleNavClick = (pageId) => {
      setCurrentPage(pageId);
    };
    
    return (
      <div 
        data-name="sidebar" 
        className={`sidebar fixed top-0 left-0 z-10 h-full w-64 pt-16 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 shadow transition-transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div data-name="sidebar-content" className="p-4">
          <nav data-name="sidebar-nav">
            <ul data-name="nav-list" className="space-y-2">
              {navItems.map(item => (
                <li key={item.id}>
                  <a
                    data-name={`nav-${item.id}`}
                    href="#"
                    className={`nav-link flex items-center p-2 text-base font-medium ${
                      currentPage === item.id ?
                      'active' :
                      'text-slate-600 dark:text-slate-300'
                    }`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(item.id);
                    }}
                  >
                    <i className={`fas ${item.icon} w-6`}></i>
                    <span>{item.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          
          <div data-name="sidebar-footer" className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700">
            <div data-name="app-info" className="text-xs text-slate-500 dark:text-slate-400">
              <div data-name="app-version" className="mb-1">AI Agenetic v1.0.0</div>
              <div data-name="quantum-info" className="neutrino-pulse">
                <i className="fas fa-atom mr-1"></i>
                <span>Quantum-Inspired Processing</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Sidebar render error:', error);
    reportError(error);
    return <div data-name="sidebar-error" className="text-red-600 p-4">Error loading sidebar.</div>;
  }
}
