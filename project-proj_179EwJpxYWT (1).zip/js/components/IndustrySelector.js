function IndustrySelector({ selectedIndustry, onIndustryChange }) {
  try {
    const [industries, setIndustries] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    
    React.useEffect(() => {
      fetchIndustries();
    }, []);
    
    const fetchIndustries = () => {
      try {
        setLoading(true);
        const fetchedIndustries = getIndustries();
        setIndustries(fetchedIndustries);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching industries:', error);
        setLoading(false);
      }
    };
    
    const handleIndustryClick = (industryId) => {
      // If already selected, deselect (set to null)
      if (selectedIndustry === industryId) {
        onIndustryChange(null);
      } else {
        onIndustryChange(industryId);
      }
    };
    
    if (loading) {
      return (
        <div data-name="industry-selector-loading" className="mb-6 flex justify-center">
          <div data-name="loading-spinner" className="quark-spin">
            <i className="fas fa-circle-notch text-indigo-600 text-xl"></i>
          </div>
        </div>
      );
    }
    
    return (
      <div data-name="industry-selector" className="mb-6">
        <div data-name="selector-header" className="flex justify-between items-center mb-3">
          <h3 data-name="selector-title" className="text-lg font-medium">Filter by Industry</h3>
          {selectedIndustry && (
            <button
              data-name="clear-filter"
              className="text-sm text-indigo-600 hover:text-indigo-800"
              onClick={() => onIndustryChange(null)}
            >
              Clear filter
            </button>
          )}
        </div>
        
        <div data-name="industries-grid" className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {industries.map(industry => (
            <div
              data-name="industry-item"
              key={industry.id}
              className={`p-3 rounded-lg cursor-pointer transition-all ${
                selectedIndustry === industry.id ?
                'bg-indigo-100 dark:bg-indigo-900/50 border-2 border-indigo-500' :
                'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700'
              }`}
              onClick={() => handleIndustryClick(industry.id)}
            >
              <div data-name="industry-content" className="flex flex-col items-center text-center">
                <div data-name="industry-icon" className={`${industry.color} w-12 h-12 rounded-full flex items-center justify-center mb-2`}>
                  <i className={industry.icon}></i>
                </div>
                <span data-name="industry-name" className="text-sm font-medium">
                  {industry.name}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('IndustrySelector render error:', error);
    reportError(error);
    return <div data-name="industry-error" className="text-red-600 p-4">Error loading industry selector.</div>;
  }
}
